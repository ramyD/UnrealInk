#pragma once

#include "Engine.h"
#include "InkGameClasses.h"

// Ink category
DECLARE_LOG_CATEGORY_EXTERN(InkRuntime, Log, All);