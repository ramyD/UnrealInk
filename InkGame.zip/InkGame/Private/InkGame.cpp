#include "InkGame.h"

IMPLEMENT_GAME_MODULE(FDefaultGameModuleImpl, "Snow" )
DEFINE_LOG_CATEGORY( InkRuntime );